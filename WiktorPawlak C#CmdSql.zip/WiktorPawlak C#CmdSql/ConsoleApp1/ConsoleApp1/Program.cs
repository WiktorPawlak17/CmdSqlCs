﻿using System.Data.SqlClient;

class Program{
    static void Main(){
        //Establish connection from my computer, Initial Catalog = name of your database
        string connString = "Data Source = "+ Environment.MachineName + "; Initial Catalog=Dostawy;Integrated Security = true";
        SqlConnection conn = new SqlConnection(connString);
        try{
            conn.Open();
            Console.WriteLine("Connected to a database");
            bool endProgram = false;
            while (!endProgram){
                Console.WriteLine("Pick an operation : \n 0. End Program \n 1. Add new delivery \n 2. Display warehouse \n 3. Display deliveries from a period");
                string option = Console.ReadLine();
                switch (option){
                    case "0":
                        endProgram = true;
                        break;
                    case "1":
                        Console.WriteLine("Add new distributor? (yes/no)");
                        string addDistributor = Console.ReadLine();
                        string nip = "";
                        if (addDistributor.ToLower() == "yes"){
                            nip = addNewDistributorAndReturnNIP(conn, nip);
                        }
                        string queryCount = "Select Count (*) from Dostawy_1";
                        SqlCommand cmdCount = new SqlCommand(queryCount, conn);
                        SqlDataReader countRowsReader = cmdCount.ExecuteReader();
                        int newID; //Initialize here, because i'm gonna need this later
                        if (countRowsReader.Read()) {
                            newID = countRowsReader.GetInt32(0) + 1;
                        }
                        else{
                            newID = 1;
                        }
                        countRowsReader.Close();
                        string inputDate = addAndReturnDateOfDelivery(conn);
                        
                        string inputNip; //Making sure user does not have to input NIP twice
                        if (addDistributor.ToLower() == "yes"){
                            inputNip = nip;
                        }
                        else {
                            Console.WriteLine("Insert NIP of company");
                            inputNip = Console.ReadLine();
                        }
                        buildAndExecuteInsertQuery(conn,newID,inputDate,inputNip);
                        bool keepAdding = true;
                        while (keepAdding){
                            addNewProduct(conn,newID);
                            Console.WriteLine("Add another product ?(yes/no) ");
                            string anotherOne = Console.ReadLine();
                            if (anotherOne.ToLower() == "no"){
                                keepAdding = false;
                            }
                        }
                        break;
                    case "2":
                        displayAllItems(conn);
                        break;
                    case "3":
                        displaySpecificItems(conn);
                        break;
                    default:
                        break;
                }
            }
        }
        catch (Exception e){
            Console.WriteLine(e.ToString());
        }
    }
    static string addNewDistributorAndReturnNIP(SqlConnection conn, string nip)
    {
        //checkForBadNip
        bool badNip = true;
        while (badNip){
            Console.WriteLine("Insert NIP");
            nip = Console.ReadLine();
            if (nip.Length == 11){
                badNip = false;
            }
            else{
                Console.WriteLine("Invalid NIP");
            }
        }
        Console.WriteLine("Insert company name");
        string nameOfCompany = Console.ReadLine();
        string queryInsert = "INSERT INTO Dostawcy_1 (NIP, Nazwa) VALUES (@NIP, @NameOfCompany)"; //This way SQL injection is prevented
        SqlCommand cmdInsert = new SqlCommand(queryInsert, conn);
        cmdInsert.Parameters.AddWithValue("@NIP", nip);
        cmdInsert.Parameters.AddWithValue("@NameOfCompany", nameOfCompany);
        cmdInsert.ExecuteNonQuery();
        Console.WriteLine("Distributor added successfully.");
        return nip;
    }
    static string addAndReturnDateOfDelivery(SqlConnection conn)
    {
        bool badDate = true;
        string inputDate = "";
        DateTime currentDate = DateTime.Today;
        while (badDate){
            Console.WriteLine("Insert date of delivery YYYY-MM-DD");
            inputDate = Console.ReadLine();
            if (inputDate.Length == 10 && int.Parse(inputDate.Substring(0, 4)) > 1900 && int.Parse(inputDate.Substring(0, 4)) <= currentDate.Year
                && int.Parse(inputDate.Substring(5,2)) > 0 && int.Parse(inputDate.Substring(5,2)) <= 12 && int.Parse(inputDate.Substring(8,2)) > 0
                && int.Parse(inputDate.Substring(8,2))<= 31) // Constrains Year (1900, current Year), Month (1,12), Day (1,31) 
            {
                badDate = false;
            }else
            {
                Console.WriteLine("Bad date");
            }
        }
        return inputDate;
    }
    static void buildAndExecuteInsertQuery(SqlConnection conn,int newID,string inputDate, string inputNip)
    {
        string queryInsertDevilery = "Insert into Dostawy_1 (Numer_Dostawy,Data_dostawy,NIP_dostawcy)" +
                                " Values (@nr_dostawy,@data_dostawy,@nip)";
        SqlCommand cmdInsertDelivery = new SqlCommand(queryInsertDevilery, conn);
        cmdInsertDelivery.Parameters.AddWithValue("@nr_dostawy", newID);
        cmdInsertDelivery.Parameters.AddWithValue("@data_dostawy", inputDate);
        cmdInsertDelivery.Parameters.AddWithValue("@nip", inputNip);
        cmdInsertDelivery.ExecuteNonQuery();
        Console.WriteLine("New delivery added");
    }
    static void addNewProduct(SqlConnection conn, int newID)
    {
        Console.WriteLine("Name of product : ");
        string nameOfProduct = Console.ReadLine();
        Console.WriteLine("Amount of product : ");
        string amountOfProduct = Console.ReadLine();
        string queryInsertProduct = "Insert Into Produkty_w_magazynie (nazwa_produktu,ilość_produktu,numer_dostawy) Values (@product_name,@product_amount,@delivery_number)";
        SqlCommand cmdInsertProduct = new SqlCommand(queryInsertProduct, conn);
        cmdInsertProduct.Parameters.AddWithValue("@product_name", nameOfProduct);
        cmdInsertProduct.Parameters.AddWithValue("@product_amount", amountOfProduct);
        cmdInsertProduct.Parameters.AddWithValue("@delivery_number", newID);
        cmdInsertProduct.ExecuteNonQuery();
        Console.WriteLine("New product added to delivery nr " + newID);
    }
    static void displayAllItems(SqlConnection conn)
    {
        string querySelectAll = "Select * from Produkty_w_magazynie";
        SqlCommand cmdSelectAll = new SqlCommand(querySelectAll, conn);
        SqlDataReader reader = cmdSelectAll.ExecuteReader();
        if (reader.HasRows)
        {
            while (reader.Read())
            {
                Console.WriteLine("----------------------------------------------");
                Console.WriteLine("Nazwa produktu : " + reader.GetString(0));
                Console.WriteLine("Ilość produktu : " + reader.GetDecimal(1));
                Console.WriteLine("Numer Dostawy : " + reader.GetString(2)); // technically could be an Int/Decimal
                
            }
            Console.WriteLine("----------------------------------------------");
        }
        else
        {
            Console.WriteLine("Empty Table");
        }
        reader.Close();
    }
    static void displaySpecificItems(SqlConnection conn)
    {
        DateTime currentDate = DateTime.Today;
        Console.WriteLine("What period ? \n 1. Day \n 2. Week \n 3. Month \n 4. Year \n 5. From the beginning");
        string option2 = Console.ReadLine();
        string querySelectSpecific = "Select * from Dostawy_1 Where Data_dostawy >= @restriction";
        SqlCommand cmdSelectSpecific = new SqlCommand(querySelectSpecific, conn);
        switch (option2) {
            case "1":
                cmdSelectSpecific.Parameters.AddWithValue("@restriction", currentDate);
                break;
            case "2":
                cmdSelectSpecific.Parameters.AddWithValue("@restriction", currentDate.AddDays(-7));
                break;
            case "3":
                cmdSelectSpecific.Parameters.AddWithValue("@restriction", currentDate.AddMonths(-1));
                break;
            case "4":
                cmdSelectSpecific.Parameters.AddWithValue("@restriction", currentDate.AddYears(-1));
                break;
            case "5":
                cmdSelectSpecific = new SqlCommand("Select * from Dostawy_1", conn); // Kind of a shortcut, but easier this way
                break;
            default:
                cmdSelectSpecific.Parameters.AddWithValue("@restriction",currentDate.AddDays(1)); //Safety net
                break;
        }
        SqlDataReader readerSpecific = cmdSelectSpecific.ExecuteReader();
        if (readerSpecific.HasRows){
            while (readerSpecific.Read())
            {
                Console.WriteLine("----------------------------------------------");
                Console.WriteLine("Numer Dostawy : " + readerSpecific.GetString(0));
                Console.WriteLine("Data Dostawy : " + readerSpecific.GetDateTime(1));
                Console.WriteLine("NIP Dostawcy : " + readerSpecific.GetString(2)); // technically could be an Int/Decimal
            }
            Console.WriteLine("----------------------------------------------");
        }
        readerSpecific.Close();
    }
}